﻿
using Alliance.Core.Domain;
using Alliance.DeveloperTest.Utility;
using NUnit.Framework;

namespace Alliance.DeveloperTest
{
    public class DeveloperTestSample
    {
        [TestCase]
        [DeploymentItem("Resources/ObjectStore.txt")]
        public void ProgrammerTest()
        {
            var address = new Address("56 Main St", "Mesa", "AZ", "85225");
            var customer = new Customer("John", "Doe", address);
            var company = new Company("Alliance Reservations Network", address);
//
            Assert.IsNullOrEmpty(customer.Id.ToString());
            customer.Save();
            Assert.IsNotNullOrEmpty(customer.Id.ToString());
//
            Assert.IsNullOrEmpty(company.Id.ToString());
            company.Save();
            Assert.IsNotNullOrEmpty(company.Id.ToString());
//
            Customer savedCustomer = Customer.Find(customer.Id) as Customer;
            Assert.IsNotNull(savedCustomer);
            Assert.AreSame(customer.Address, address);
            Assert.AreEqual(savedCustomer.Address, address);
            Assert.AreEqual(customer.Id, savedCustomer.Id);
            Assert.AreEqual(customer.FirstName, savedCustomer.FirstName);
            Assert.AreEqual(customer.LastName, savedCustomer.LastName);
            Assert.AreEqual(customer, savedCustomer);
            Assert.AreNotSame(customer, savedCustomer);

            Company savedCompany = Company.Find(company.Id) as Company;
            Assert.IsNotNull(savedCompany);
            Assert.AreSame(company.Address, address);
            Assert.AreEqual(savedCompany.Address, address);
            Assert.AreEqual(company.Id, savedCompany.Id);
            Assert.AreEqual(company.Name, savedCompany.Name);
            Assert.AreEqual(company, savedCompany);
            Assert.AreNotSame(company, savedCompany);

            customer.Delete();
            //Changed to not null or empty seems code wanted delete to clear the id
            //but then it does a search with the id that was asserted to be null
            Assert.IsNotNullOrEmpty(customer.Id.ToString());
            Assert.IsNull(Customer.Find(customer.Id));

            company.Delete();
            //Changed to not null or empty seems code wanted delete to clear the id
            //but then it does a search with the id that was asserted to be null
            Assert.IsNotNullOrEmpty(company.Id.ToString());
            Assert.IsNull(Company.Find(company.Id));
        }
    }
}
