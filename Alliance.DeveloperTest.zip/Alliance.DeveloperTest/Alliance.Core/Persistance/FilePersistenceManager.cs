using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using NClone;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Alliance.Core.Persistance
{
    /// <summary>
    /// Persist T to file
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class FilePersistenceManager<T> : IPersistanceManger<T> where T : class, IUnique
    {
        private const string FileName = @"Resources\ObjectStore.txt";
        private static List<ObjectWrapper<IUnique>> wrapper;

        string path = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), FileName);

        public void Save(T instance)
        {
            var wrappedObject = new ObjectWrapper<IUnique>(instance.GetType(),instance);
            ObjectStore.Add(Clone.ObjectGraph(wrappedObject));
            //note: not persisting to file, just using the simple cache
            //writing to the file and syncing the cache does not seem necessary for this exercise
        }

        public void Delete(T instance)
        {
            ObjectStore.RemoveAll(ow => ow.Data.Id == instance.Id);
            //note: not deleting file, just using the simple cache
            //writing to the file and syncing the cache does not seem necessary for this exercise
        }

        public T Find(Guid? id) 
        {
            ObjectWrapper<IUnique> result = ObjectStore.SingleOrDefault(ow => ow.Data.Id == id.Value);
            return result != null ? (T)result.Data : null as T;
        }

        /// <summary>
        /// Initialize the cache from the file.  We are not actually writing to a file, 
        /// but this would demonstrate how to load the cache from the file
        /// </summary>
        private List<ObjectWrapper<IUnique>> ObjectStore
        {
            get
            {
                if (wrapper != null)
                {
                    return wrapper;
                }

                using (StreamReader file = File.OpenText(path))
                using (JsonTextReader reader = new JsonTextReader(file))
                {
                    try
                    {
                        var o2 = JArray.ReadFrom(reader);
                        wrapper = JsonConvert.DeserializeObject<List<ObjectWrapper<IUnique>>>(o2.ToString());
                    }
                    catch
                    {
                        //not really doing anything with these for now
                        wrapper = new List<ObjectWrapper<IUnique>>();
                    }
                    return wrapper;
                }
            }
        }

    }
}