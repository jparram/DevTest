﻿using System;

namespace Alliance.Core.Persistance
{
    /// <summary>
    /// Implementations of this interface will have a globally unique id
    /// </summary>
    public interface IUnique
    {
        Guid? Id { get; }
    }
}