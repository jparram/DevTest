﻿using System;

namespace Alliance.Core.Persistance
{
    public class ObjectWrapper<T>  where T: IUnique
    {
        public Type RecordType { get; private set; }
        public T Data { get; private set; }

        public ObjectWrapper(Type type, T data)
        {
            RecordType = type;
            Data = data;
        }
    }
}