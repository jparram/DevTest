using System;

namespace Alliance.Core.Persistance
{
    /// <summary>
    /// Interface to define the required persistence methods 
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IPersistanceManger<T>
    {
        void Save(T instance);
        void Delete(T instance);
        T Find(Guid? id);
    }
}