﻿using System;
using Alliance.Core.Persistance;

namespace Alliance.Core.Domain
{
    /// <summary>
    /// Base class for implementations of Customer
    /// </summary>
    public abstract class CustomerBase : IUnique
    {
        //Ideally this would be an injected dependency
        private static readonly IPersistanceManger<CustomerBase> Persistance = new FilePersistenceManager<CustomerBase>();

        /// <summary>
        /// Construct customer with firstName, lastName and an address
        /// </summary>
        /// <param name="firstName"></param>
        /// <param name="lastName"></param>
        /// <param name="address"></param>
        protected CustomerBase(string firstName, string lastName, AddressBase address)
        {
            FirstName = firstName;
            LastName = lastName;
            Address = address;
        }

        public string FirstName { get; private set; }
        public string LastName { get; private set; }
        public AddressBase Address { get; private set; }

        public Guid? Id { get; private set; }

        /// <summary>
        /// Persists customer
        /// </summary>
        public void Save()
        {
            if (this.Id.HasValue == false)
            {
                this.Id = Guid.NewGuid();
            }
            if (this.Address != null && this.Address.Id.HasValue == false)
            {
                this.Address.Id = Guid.NewGuid();
            }
            Persistance.Save(this);
        }

        /// <summary>
        /// Removes persisted customer
        /// </summary>
        public void Delete()
        {
            Persistance.Delete(this);
           
        }

        /// <summary>
        /// Find the customer with the provided id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static CustomerBase Find(Guid? id)
        {
            return Persistance.Find(id);
        }
        
        public override bool Equals(object obj)
        {
            if (obj == null)
            return base.Equals(obj);
            
            var comparison = obj as CustomerBase;

            return this.Address.Equals(comparison.Address)
                   && this.Id == comparison.Id
                   && this.FirstName == comparison.FirstName
                   && this.LastName == comparison.LastName;
        }
    }

    public class Customer : CustomerBase
    {
        public Customer(string firstName, string lastName, AddressBase address) : base(firstName, lastName, address)
        {
        }
    }
}