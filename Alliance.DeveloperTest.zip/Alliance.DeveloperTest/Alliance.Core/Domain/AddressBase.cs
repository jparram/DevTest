using System;

namespace Alliance.Core.Domain
{
    /// <summary>
    /// Base class for implementations of Address
    /// </summary>
    public abstract class AddressBase
    {

        /// <summary>
        /// Construct address with street, city, state and zip code
        /// </summary>
        /// <param name="street"></param>
        /// <param name="city"></param>
        /// <param name="state"></param>
        /// <param name="zipCode"></param>
        protected AddressBase(string street, string city, string state, string zipCode)
        {
            Street = street;
            City = city;
            State = state;
            ZipCode = zipCode;
        }

        public string Street { get; private set; }
        public string City { get; private set; }
        public string State { get; private set; }
        public string ZipCode { get; private set; }

        public Guid? Id { get; set; }

        public override bool Equals(object obj)
        {
            var comparison = obj as AddressBase;
            if (obj == null) return base.Equals(obj);

            return comparison.Id == this.Id
                   && comparison.City == this.City
                   && comparison.State == this.State
                   && comparison.Street == this.Street
                   && comparison.ZipCode == this.ZipCode;
        }
    }

    public class Address : AddressBase
    {
        public Address(string street, string city, string state, string zipCode)
            : base(street, city, state, zipCode)
        {
        }
    }
}