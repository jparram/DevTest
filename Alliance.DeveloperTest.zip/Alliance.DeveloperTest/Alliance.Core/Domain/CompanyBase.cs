﻿using System;
using Alliance.Core.Persistance;

namespace Alliance.Core.Domain
{
    /// <summary>
    /// Base class for implementations of Company
    /// </summary>
    public abstract class CompanyBase : IUnique
    {
        //Ideally this would be an injected dependency
        private static readonly IPersistanceManger<CompanyBase> Persistance = new FilePersistenceManager<CompanyBase>();

        protected CompanyBase(string name, AddressBase address)
        {
            Name = name;
            Address = address;
        }

        public Guid? Id { get; private set; }
        public string Name { get; private set; }
        public AddressBase Address { get; private set; }

        /// <summary>
        /// Persists Company
        /// </summary>
        public void Save()
        {
            if (this.Id.HasValue == false)
            {
                this.Id = Guid.NewGuid();
            }
            if (this.Address != null && this.Address.Id.HasValue == false)
            {
                this.Address.Id = Guid.NewGuid();
            }
            Persistance.Save(this);
        }

        /// <summary>
        /// Removes persisted Company
        /// </summary>
        public void Delete()
        {
            Persistance.Delete(this);
        }

        /// <summary>
        /// Find the company with the provided Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static CompanyBase Find(Guid? id)
        {
            return Persistance.Find(id);
        }

        public override bool Equals(object obj)
        {
            if (obj == null) return base.Equals(obj);

            var comparison = obj as CompanyBase;

            return this.Address.Equals(comparison.Address)
                   && this.Id == comparison.Id
                   && this.Name == comparison.Name;

        }
    }

    public class Company : CompanyBase
    {
        public Company(string name, AddressBase address) : base(name, address)
        {
        }
    }

}
